<template>
  <div>
    <app-products></app-products>

  </div>
</template>

<script>

import addBlog from './components/addBlog.vue'
import showBlogs from './components/showBlogs.vue'
import Header from './components/Header.vue'
import Products from './components/products.vue'

export default {

  components:
  {
      'add-Blog':addBlog,
      'show-Blogs':showBlogs,
      'app-header':Header,
      'app-products':Products
  },
  data () {
    return {
          }
  }
}






</script>

<style scoped>

</style>
