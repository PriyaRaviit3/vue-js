<template>
  <div id="app-products">
    <div v-for="product in products">
      <h2>{{product.partid}}</h2>
      <article>{{product.partname}}</article>
    </div>
  </div>
</template>

<script>
export default {

  data () {
    return {
      products:[]
    }
  },
  created()
  {
      this.$http.get('http://emsapplication.azurewebsites.net/api/parts'
      ).then(function(data){
        //console.log(data);
        return data.json();
      }).then(function(data){
        console.log(data);

        var productsArray=[];
        for(let key in data)
        {
          productsArray.push(data[key]);
        }
        this.products=productsArray;

      });


  }
}
</script>

<style>

</style>
